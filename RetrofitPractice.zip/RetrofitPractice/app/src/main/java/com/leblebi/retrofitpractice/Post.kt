package com.leblebi.retrofitpractice


class Post {
    private var userId:Int=0
    private var id:Int=0
    private lateinit var title :String

    //@SerializedName('body')
    private lateinit var text:String


}